package block.chain.views;

import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ComboBox;
import javafx.geometry.Insets;
import javafx.collections.FXCollections;
import block.chain.models.User;
import block.chain.models.UserType;
import block.chain.controllers.UserController;

public class UpdateAccountView extends VBox{

	private Stage primaryStage;
	
	public UpdateAccountView(Stage primaryStage) {
		this.primaryStage = primaryStage;
		primaryStage.setResizable(false);
		initComponents();
	}
	
	private void initComponents() {
		
		setPrefWidth(700);
		setPrefHeight(400);
		
		Button backButton = new Button("Back to login");
		backButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		setMargin(backButton, new Insets(5,0,0,5));
		backButton.setFont(Font.font(18));
		backButton.setOnAction(e->{
			primaryStage.setScene(Main.prevScene);
		});
				
		Label lblHeading = new Label("Create an account.");
		lblHeading.setFont(Font.font(30));
		setMargin(lblHeading, new Insets(10,0,20,200));
		
		Label lblUsername = new Label("Username:");
		lblUsername.setFont(Font.font(20));
		setMargin(lblUsername, new Insets(5,0,0,5));
		
		TextField tfUsername = new TextField();
		tfUsername.setFont(Font.font(16));
		tfUsername.setPrefColumnCount(30);
		setMargin(tfUsername, new Insets(5,0,0,5));
		
		HBox userBox = new HBox(30);
		userBox.getChildren().addAll(lblUsername,tfUsername);
		setMargin(userBox, new Insets(5,0,20,30));
		
		Label lblPassword = new Label("Password:");
		lblPassword.setFont(Font.font(19));
		setMargin(lblPassword, new Insets(5,0,0,5));
		
		PasswordField pfPassword = new PasswordField();
		pfPassword.setFont(Font.font(16));
		pfPassword.setPrefColumnCount(30);
		setMargin(pfPassword, new Insets(5,0,0,5));	
		
		HBox passwordBox = new HBox(40);
		passwordBox.getChildren().addAll(lblPassword,pfPassword);
		setMargin(passwordBox, new Insets(5,0,10,30));		
		
		Label lblUserType = new Label("User type:");
		lblUserType.setFont(Font.font(20));
		setMargin(lblUserType, new Insets(5,0,0,5));
						
		ComboBox<UserType> cbUserType = new ComboBox<>(FXCollections.observableArrayList(UserType.GOVERNMENT_OFFICIAL,
												UserType.CONTRACTOR));
		cbUserType.setPrefWidth(465);
		setMargin(cbUserType, new Insets(5,0,0,5));		
		
		HBox userTypeBox = new HBox(37);
		userTypeBox.getChildren().addAll(lblUserType,cbUserType);
		setMargin(userTypeBox, new Insets(5,0,20,30));
		
		Label lblIsActive = new Label("Active:");
		lblIsActive.setFont(Font.font(20));
		setMargin(lblIsActive, new Insets(5,0,0,5));
		
		ComboBox<String> cbIsActive = new ComboBox<>(FXCollections.observableArrayList("True","False"));
		cbIsActive.setPrefWidth(465);
		setMargin(cbIsActive, new Insets(5,0,0,5));
		
		HBox isActiveBox = new HBox(37);
		isActiveBox.getChildren().addAll(lblIsActive,cbIsActive);
		setMargin(isActiveBox, new Insets(5,0,20,60));
		
		Button createAccountButton = new Button("Create Account");
		createAccountButton.setFont(Font.font(18));
		createAccountButton.setStyle("-fx-background-color:green;");
		createAccountButton.setOnAction(e->{
			
			if(!tfUsername.getText().equals("") && !pfPassword.getText().equals("") && (cbUserType.getValue() != null) &&
					(cbIsActive.getValue() != null)) {
			
				User user = new User(tfUsername.getText(), pfPassword.getText(),cbUserType.getValue());		
				boolean isCreated = UserController.createAccount(user);
				
				if(isCreated)
					showResponseAlert("createdAccount", "Account successfully created!","Success");
				else
					showResponseAlert("error", "Failed to create account!","Error");

			}
			else {
				String msg = "Please enter: Username, Password, UserType and Active status.";
				showResponseAlert("error",msg,"Error");
			}
				System.out.println();
						
		});
		setMargin(createAccountButton, new Insets(5,0,0,300));
				
		Button updateAccountButton = new Button("Update Account");
		updateAccountButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		updateAccountButton.setStyle("-fx-background-color:yellow;");
		updateAccountButton.setTextFill(Color.BLACK);
		updateAccountButton.setFont(Font.font(18));
		updateAccountButton.setOnAction(e->{
			
			if((!tfUsername.getText().equals("") && !pfPassword.getText().equals("") && (cbIsActive.getValue() != null)) || 
					(cbUserType.getValue() != null)) {
			
				User user = null;
				
				if(cbIsActive.getValue().equals("True")) 
					user = new User(tfUsername.getText(), pfPassword.getText(), cbUserType.getValue(), true);
				else
					user = new User(tfUsername.getText(), pfPassword.getText(), cbUserType.getValue(), false);
					
				boolean isUpdated = UserController.updateAccount(user);
				
				if(isUpdated)
					showResponseAlert("updateAccount", "Account active status successfully updated!","Success");
				else
					showResponseAlert("error", "Failed to update account active status!","Error");
			}
			else {
				String msg = "Please enter: Username, Password and Active status, UserType is optional.\nNote: This action only updates the user's " + 
							"active status.";
				showResponseAlert("error",msg,"Error");
			}
						
		});
		setMargin(updateAccountButton, new Insets(5,0,0,300));
		
		HBox buttonBox = new HBox(37);
		buttonBox.getChildren().addAll(createAccountButton,updateAccountButton);
		setMargin(buttonBox, new Insets(5,0,20,210));
		
		getChildren().addAll(backButton,lblHeading,userBox,passwordBox,userTypeBox,isActiveBox,buttonBox);					
	}
	
	private void showResponseAlert(String alertType, String message, String title) {
	
		Alert alert = null;
		
		if(alertType.equals("error"))
			alert = new Alert(Alert.AlertType.ERROR);
		else if(alertType.equals("createdAccount") || alertType.equals("updateAccount"))
			alert = new Alert(Alert.AlertType.INFORMATION);
			
		if(alert != null) {
		
			alert.setWidth(400);
	        alert.setHeight(400);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);    
	        alert.showAndWait();
		}        
    }
}
