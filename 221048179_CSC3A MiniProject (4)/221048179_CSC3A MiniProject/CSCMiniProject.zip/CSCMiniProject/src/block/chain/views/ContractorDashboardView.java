package block.chain.views;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ContractorDashboardView extends VBox{

	private Stage primaryStage;
	
	public ContractorDashboardView(Stage primaryStage) {
		
		this.primaryStage = primaryStage;
		initComponents();
	}

	public void initComponents() {
		
		setPrefWidth(600);
		setPrefHeight(600);
		
		Button backButton = new Button("Back to login");  
	    backButton.setStyle("-fx-background-color: #FF99FF; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
	    backButton.setOnAction(e->{	    	
	    	primaryStage.setScene(Main.loginScene);	
	    });
	    setMargin(backButton, new Insets(5));
	
	    Label welcomeLabel = new Label("Welcome to the Contractor Dashboard");
	    welcomeLabel.setFont(Font.font("Arial", 18));
	    welcomeLabel.setStyle("-fx-font-weight: bold;");
	    setMargin(welcomeLabel, new Insets(5,0,5,150));
	    
	    Button viewTransactionsButton = new Button("View Submitted Transactions");
	    viewTransactionsButton.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
	    viewTransactionsButton.setOnAction(e -> {
	        
	    	Main.prevScene = primaryStage.getScene();
	    	primaryStage.setScene(new Scene(new ViewTransactionsView<>(Main.BLOCKCHAIN,primaryStage)));
	    	primaryStage.show();
	    	
	    });
	    setMargin(viewTransactionsButton, new Insets(5));
	
	    Button btnViewProjects = new Button("View My Projects");
        btnViewProjects.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        btnViewProjects.setOnAction(e -> {
            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(new Scene(new ProjectsView(primaryStage)));
            primaryStage.show();
        });
        setMargin(btnViewProjects, new Insets(5));
	    	    
	  //<a href="https://www.flaticon.com/free-icons/email" title="email icons">Email icons created by Freepik - Flaticon</a>
	    Image image = new Image("file:logo\\inbox2.png",40,40,false,true);
	    ImageView imageView = new ImageView(image);
	    Button btnInbox = new Button("Inbox", imageView);
	    btnInbox.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
	    btnInbox.setOnAction(e -> {
	    	Main.prevScene = primaryStage.getScene();
	    	primaryStage.setScene(new Scene(new InboxView(primaryStage)));
	    	primaryStage.show();
	    });       
	    setMargin(btnInbox, new Insets(5));
	    
	    getChildren().addAll(welcomeLabel,viewTransactionsButton,btnViewProjects,backButton, btnInbox);
	}
}
