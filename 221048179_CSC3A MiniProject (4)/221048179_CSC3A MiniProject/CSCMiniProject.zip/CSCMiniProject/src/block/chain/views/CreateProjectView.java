package block.chain.views;

import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import block.chain.controllers.ProjectsController;

public class CreateProjectView extends VBox{

	private Stage primaryStage;
	
	
	public CreateProjectView(Stage primaryStage) {
		this.primaryStage = primaryStage;
		
		initComponents();
	}
		
	protected void initComponents() {
		
		setPrefWidth(700);
		setPrefHeight(600);
		
		Button backButton = new Button("Back to Dashboard");
		backButton.setStyle("-fx-background-color: #60C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		setMargin(backButton,new Insets(15));
		backButton.setOnAction(e->{			
			
			primaryStage.setScene(Main.prevScene);
			primaryStage.show();
		});
		setMargin(backButton,new Insets(6));
		
		Label lblName = new Label("Project Name: ");
		setMargin(lblName,new Insets(5));
		
		TextField tfName = new TextField();
		tfName.setPrefColumnCount(10);
		setMargin(tfName,new Insets(5));
		
		Label lblDescription = new Label("Description: ");
		setMargin(lblDescription,new Insets(5));
		
		TextArea taDescription = new TextArea();		
		setMargin(taDescription,new Insets(5));
		
		Label lblStartDate = new Label("Start Date: eg 2007-12-03T10:15:30 ");
		setMargin(lblStartDate,new Insets(5));
		
		TextField tfStartDate = new TextField();
		tfStartDate.setPrefColumnCount(10);
		setMargin(tfStartDate,new Insets(5));
		
		Label lblEndDate = new Label("End Date: eg 2007-12-03T10:15:30");
		setMargin(lblEndDate,new Insets(5));
		
		TextField tfEndDate = new TextField();
		tfEndDate.setPrefColumnCount(10);
		setMargin(tfEndDate,new Insets(5));
		
		Label lblBudget = new Label("Budget: R");
		setMargin(lblBudget,new Insets(5));
		
		TextField tfBudget = new TextField();
		tfBudget.setPrefColumnCount(10);
		setMargin(tfBudget,new Insets(5));
		
		Label lblOfficialUsername = new Label("Government Official username: ");
		setMargin(lblOfficialUsername,new Insets(5));
		
		TextField tfOfficialUsername = new TextField();		
		setMargin(tfOfficialUsername,new Insets(5));
			
		Label lblContractorUsername = new Label("Contractor username: ");
		setMargin(lblContractorUsername,new Insets(5));
		
		TextField tfContractorUsername = new TextField();
		tfContractorUsername.setPrefColumnCount(10);
		setMargin(tfContractorUsername,new Insets(5));		
		
		Label lblIsCompleted = new Label("Is Completed: ");
		setMargin(lblIsCompleted,new Insets(5));
		
		TextField tfIsCompleted = new TextField();
		tfIsCompleted.setPrefColumnCount(10);
		setMargin(tfIsCompleted,new Insets(5));
		
		Button btnAddProject = new Button("Create Project");
		btnAddProject.setStyle("-fx-background-color: #60C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnAddProject.setOnAction(e->{
			
			if(!tfName.getText().equals("") && !taDescription.getText().equals("") && !tfStartDate.getText().equals("") && 
					!tfEndDate.getText().equals("") &&
					!tfBudget.getText().equals("") && !tfOfficialUsername.getText().equals("") && !tfContractorUsername.getText().equals("")
					&& !tfIsCompleted.getText().equals("")) {
			
				if(ProjectsController.createProject(tfName.getText(), taDescription.getText(), tfStartDate.getText(), tfEndDate.getText() ,
						Double.parseDouble(tfBudget.getText()), tfOfficialUsername.getText(), tfContractorUsername.getText(),
						Boolean.parseBoolean(tfIsCompleted.getText())))	
					showConfirmationAlert("success","Project successfully created!");			
				else
					showConfirmationAlert("error","Failed to create the project!!");
			}					
			
		});
		
		HBox btnBox = new HBox(10);
		btnBox.getChildren().addAll(btnAddProject);
		setMargin(btnBox, new Insets(5,0,10,250));
		
		getChildren().addAll(backButton,lblName, tfName, lblDescription, taDescription, lblStartDate, tfStartDate, lblEndDate, tfEndDate, lblBudget, tfBudget,
			 lblOfficialUsername, tfOfficialUsername, lblContractorUsername, tfContractorUsername, lblIsCompleted, tfIsCompleted, btnBox);
				
	}
	
	private void showConfirmationAlert(String type, String msg) {
		
        Alert alert;
        
        if(type.equals("success")) {
        
        	alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText(msg);
        }
        else {
        	alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(msg);
        }
        
        
        alert.showAndWait();
    }
}
