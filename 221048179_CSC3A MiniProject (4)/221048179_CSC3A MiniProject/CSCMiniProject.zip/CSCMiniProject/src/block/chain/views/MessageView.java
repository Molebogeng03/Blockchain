package block.chain.views;

import java.util.ArrayList;

import block.chain.models.Inbox;
import block.chain.models.Message;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MessageView extends VBox{

	private ArrayList<VBox> components;
	private Inbox inbox;
	private Stage primaryStage;
	private ListView<VBox> listView;
	
	public MessageView(Inbox inbox, Stage stage) {
		
		this.inbox = inbox;
		primaryStage = stage;	
		components = new ArrayList<>();
		initComponents();
	}
	
	public void initComponents() {
		
		setPrefWidth(990);
		setPrefHeight(600);
						
		Button btnBack = new Button("Back");
		btnBack.setOnAction(e->{
			
			primaryStage.setScene(Main.prevScene);
			primaryStage.show();
		});;
		setMargin(btnBack, new Insets(10));
		
		listView = new ListView<>(FXCollections.observableArrayList(createMessageBox()));
		listView.setPrefHeight(600);
		setMargin(listView, new Insets(10));
		
		getChildren().addAll(btnBack, listView);
	}
	
	private ArrayList<VBox> createMessageBox() {
		
		for(Message msg : inbox.getMessages()) {
			
			if(msg != null) {
				
				Label lblSender = new Label("Sender: ");
				TextField tfSender = new TextField();
				tfSender.setText(msg.getSenderUsername());
				tfSender.setEditable(false);
				setMargin(tfSender, new Insets(5,0,5,10));
				
				Label lblReceiver = new Label("Receiver: ");
				TextField tfReceiver = new TextField();
				tfReceiver.setText(msg.getReceiverUsername());
				tfReceiver.setEditable(false);
				setMargin(tfReceiver, new Insets(5,0,5,10));
				
				Label lblMessage = new Label("Message: ");
				TextArea taMessage = new TextArea();
				taMessage.setPrefHeight(70);
				taMessage.setText(msg.getMessage());
				taMessage.setEditable(false);
				setMargin(taMessage, new Insets(5,0,5,10));
				
				HBox hbox1 = new HBox(5);
				hbox1.getChildren().addAll(lblSender, tfSender);
				setMargin(hbox1, new Insets(5));
				
				HBox hbox2 = new HBox(5);
				hbox2.getChildren().addAll(lblReceiver, tfReceiver);
				setMargin(hbox2, new Insets(5));
				
				HBox hbox3 = new HBox(5);
				hbox3.getChildren().addAll(lblMessage, taMessage);
				setMargin(hbox3, new Insets(5));
				
				VBox messageBox = new VBox(5);
				messageBox.getChildren().addAll(hbox1,hbox2,hbox3);
				
				components.add(messageBox);
			}
		}
		return components;
	}
}
