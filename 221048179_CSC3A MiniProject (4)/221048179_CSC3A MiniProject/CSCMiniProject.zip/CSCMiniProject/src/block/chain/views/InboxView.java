package block.chain.views;

import java.util.ArrayList;

import block.chain.models.Inbox;
import block.chain.models.UserType;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class InboxView extends VBox{
	
	private ArrayList<Inbox> inbox;
	
	// visual components
	private Stage primaryStage;
	private ListView<Inbox> listView;
	
	public InboxView(Stage primaryStage) {
		this.primaryStage = primaryStage;
		inbox = new ArrayList<>();
		initComponents();
	}
	
	protected void initComponents() {
		
		setPrefWidth(700);
		setPrefHeight(600);					
		
		Button btnInboxes = new Button("Get Inboxes");
		btnInboxes.setStyle("-fx-background-color: #64C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnInboxes.setOnAction(e->{
											
			if(Main.INBOXES.size() > 0) {
				
				for(Inbox inbox : Main.INBOXES) {
				
					if(inbox.getOwner().getUsername().equals(Main.LOGGED_IN.getUsername()) &&
							inbox.getOwner().getPassword().equals(Main.LOGGED_IN.getPassword()))
						this.inbox.add(inbox);
				}
				
				listView = createListView();
				getChildren().set(2, listView);
			}
		});
		setMargin(btnInboxes,new Insets(5,0,5,250));
			
		
		listView = createListView();
		
		Button backButton = new Button("Back to dashboard");
		backButton.setStyle("-fx-background-color: #60C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		backButton.setOnAction(e->{
			
			if(Main.LOGGED_IN.getUserType().equals(UserType.GOVERNMENT_OFFICIAL))
				primaryStage.setScene(Main.dashboardScene);
			else
				primaryStage.setScene(Main.contractorDashboardScene);
			
			primaryStage.show();
		});
		setMargin(backButton,new Insets(5));				
		
		getChildren().addAll(backButton,btnInboxes,listView);
				
	}		
	
	private ListView<Inbox> createListView(){
		
		listView = new ListView<>(FXCollections.observableArrayList(inbox));
		listView.setPrefHeight(500);
		listView.setPrefWidth(700);
		listView.setOnMouseClicked(ev->{
			Inbox inbox = listView.getSelectionModel().getSelectedItem();
			
			if(inbox != null) {
			
				Main.prevScene = primaryStage.getScene();
				MessageView messageView = new MessageView(inbox, primaryStage);			
				primaryStage.setScene(new Scene(messageView));
				primaryStage.show();
			}			
		});
		setMargin(listView,new Insets(5));
		
		return listView;
	}
}
