package block.chain.views;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.chart.LineChart;
import java.util.ArrayList;
import block.chain.controllers.UserController;
import block.chain.models.User;
import block.chain.models.UserType;
import block.chain.models.Inbox;
import block.chain.models.Project;
import block.chain.models.ProjectPriceMapper;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;

public class Main extends Application {
   
    // Stores a references to the previous scene, for
    // navigating back to the previous scene.
    public static Scene prevScene;	// ADDED
    
    // Stores a reference to the login scene to facilitate backward
    // navigation.
    public static Scene loginScene;	// ADDED
    
    public static Scene dashboardScene;
    
    public static Scene contractorDashboardScene;
    
    public static User LOGGED_IN;
    
    /* The blockchain is static because we want to have a single
     	instance of it.
     */
    public static Blockchain<ProjectPriceMapper> BLOCKCHAIN;
        
    // Temporarily stored transactions, for the purpose of displaying them.
    public static ArrayList<Transaction<ProjectPriceMapper>> TRANSACTIONS;
           
    // Stores a connection to the database.
    public static ArrayList<User> USERS;
    
    // A list of TransactionData object that will be displayed on the graph.
    public static ArrayList<TransactionData> transData = new ArrayList<>();
    
    // Stores the projects.
    public static ArrayList<Project> PROJECTS;
    
    public static ArrayList<Inbox> INBOXES;
    
    // A dashboard that contains the graph and other components. It is public static 
    // because we can access the same instance from other classes to make dynamic changes 
    // during runtime, such as updating the graph after creating a new transaction.
    public static DashboardView dashboardView;
    
    // visual components.
    private TextField usernameField = new TextField();
    private PasswordField passwordField = new PasswordField();
    private ComboBox<UserType> userTypeComboBox = new ComboBox<>();
    private ComboBox<String> cbIsActive = new ComboBox<>(FXCollections.observableArrayList("True","False"));
    public static LineChart<String, Number> lineChart;
        
    // ADDED
    static {
    	prevScene = null;
    	loginScene = null;    
    	BLOCKCHAIN = new Blockchain<>();
    	BLOCKCHAIN.registerStake("UJ ACSSE", 10);
    	USERS = new ArrayList<>();
    	TRANSACTIONS = new ArrayList<>();
    	PROJECTS = new ArrayList<>();
    	INBOXES = new ArrayList<>();
    }
    
    @Override
    public void start(Stage primaryStage) {        
      
        // Create login screen
        GridPane loginGrid = new GridPane();
        loginGrid.setPadding(new Insets(20));
        loginGrid.setVgap(10);
        loginGrid.setHgap(10);
                
        Label projectDescription = new Label("Welcome to the Blockchain System. Create an account for contractor and official before logging in.");
        projectDescription.setFont(Font.font("Arial", 16));
        projectDescription.setStyle("-fx-font-weight: bold;");
        GridPane.setColumnSpan(projectDescription, 2);
        loginGrid.add(projectDescription, 0, 0);
        
        Label usernameLabel = new Label("Username:");       
        Label passwordLabel = new Label("Password:");        
        Label userTypeLabel = new Label("Login Type:");        
        userTypeComboBox.getItems().addAll(UserType.values());
        userTypeComboBox.setValue(UserType.GOVERNMENT_OFFICIAL); // Default value
        Label activeLabel = new Label("Active:");
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        loginButton.setOnAction(e -> {
            // Perform login authentication
            boolean isAuthenticated = authenticateUser();
            if (isAuthenticated) {
                UserType userType = userTypeComboBox.getValue();
                if (userType == UserType.CONTRACTOR) {
                	Main.prevScene = loginScene;
                	contractorDashboardScene = new Scene(new ContractorDashboardView(primaryStage));
                	primaryStage.setScene(contractorDashboardScene);
                	primaryStage.show();
                } else {
                    //showDashboard(primaryStage);
                    dashboardView = new DashboardView(primaryStage);
                    dashboardScene = new Scene(dashboardView);
                    primaryStage.setScene(dashboardScene);
                }
            } else {
                showErrorAlert("Invalid credentials. Please try again.");
            }
        });
        
        Button newAccountButton = new Button("Create Account");
        newAccountButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        newAccountButton.setOnAction(e->{
        
        	prevScene = primaryStage.getScene();
        	primaryStage.setScene(new Scene(new UpdateAccountView(primaryStage)));        	
        });
                
        
        loginGrid.add(newAccountButton, 0, 1, 2, 1);
        loginGrid.add(usernameLabel, 0, 2);
        loginGrid.add(usernameField, 1, 2);
        loginGrid.add(passwordLabel, 0, 3);
        loginGrid.add(passwordField, 1, 3);
        loginGrid.add(userTypeLabel, 0, 4);
        loginGrid.add(userTypeComboBox, 1, 4);
        loginGrid.add(activeLabel, 0, 5);
        loginGrid.add(cbIsActive, 1, 5);
        loginGrid.add(loginButton, 1, 6);     
        
        //Scene loginScene = 
        loginScene = new Scene(loginGrid, 800, 400);
        // Set initial scene to login screen
        prevScene = primaryStage.getScene();	// ADDED
        primaryStage.setScene(loginScene);        
        primaryStage.setTitle("Blockchain System");
        primaryStage.show();
    }

    private boolean authenticateUser() {
    
    	if(usernameField.getText() != null && !usernameField.getText().equals("") && passwordField.getText() != null &&
    			!passwordField.getText().equals("") && userTypeComboBox.getValue() != null && (cbIsActive.getValue() != null)) {    		
    		
    		User user = null;
    		
    		if(cbIsActive.getValue().equals("True"))
    			user = new User(usernameField.getText(),passwordField.getText(),userTypeComboBox.getValue(),true);
    		else
    			user = new User(usernameField.getText(),passwordField.getText(),userTypeComboBox.getValue(),false);    		    		
    		
    		return UserController.login(user);
    	}
    	
    	
    	return false;
    }
         
    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public static void main(String[] args) {
    	    	       	       	     
        launch(args);
            	
    }
}
