package block.chain.views;

import java.util.ArrayList;
import java.util.List;

import block.chain.controllers.CreateTransactionController;
import block.chain.models.ProjectPriceMapper;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class DashboardView extends VBox {

    // Visual components.
    public static LineChart<String, Number> lineChart;
    private Stage primaryStage;

    // Variables
    private static List<TransactionData> transactionData = new ArrayList<>();

    public DashboardView(Stage primaryStage) {

        transactionData = CreateTransactionController.getGraphData();
        lineChart = CreateTransactionController.updateGraph(transactionData);
        this.primaryStage = primaryStage;

        initComponents();
    }

    protected void initComponents() {

        setPrefWidth(900);
        setPrefHeight(400);

        Button backButton = new Button("Back to Login"); // ADDED
        backButton.setStyle("-fx-background-color: #FF99FF; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        backButton.setOnAction(e -> {

            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(Main.loginScene);
            primaryStage.show();
        });
        setMargin(backButton, new Insets(5));

        Label welcomeLabel = new Label("Welcome to Government Official Dashboard. First create a project for a registerd contractor");
        welcomeLabel.setFont(Font.font("Arial", 18));
        welcomeLabel.setStyle("-fx-font-weight: bold;");
        setMargin(welcomeLabel, new Insets(5));

        HBox projectButtonsBox = new HBox(10); // Horizontal box for project buttons
        projectButtonsBox.setPadding(new Insets(10));

        Button btnCreateProject = new Button("Create Project");
        btnCreateProject.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        btnCreateProject.setOnAction(e -> {
            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(new Scene(new CreateProjectView(primaryStage)));
            primaryStage.show();
        });
        setMargin(btnCreateProject, new Insets(5));

        Button btnViewProjects = new Button("View Projects");
        btnViewProjects.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        btnViewProjects.setOnAction(e -> {
            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(new Scene(new ProjectsView(primaryStage)));
            primaryStage.show();
        });
        setMargin(btnViewProjects, new Insets(5));

        projectButtonsBox.getChildren().addAll(btnCreateProject, btnViewProjects); // Add buttons to the horizontal box

        Button viewTransactionsButton = new Button("View Transactions");
        viewTransactionsButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        viewTransactionsButton.setOnAction(e -> {

            ViewTransactionsView<ProjectPriceMapper> page = new ViewTransactionsView<>(Main.BLOCKCHAIN, primaryStage);
            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(new Scene(page));
            primaryStage.show();
        });
        setMargin(viewTransactionsButton, new Insets(5));

        Button transactionPageButton = new Button(" Create Transaction");
        transactionPageButton.setStyle("-fx-background-color: #9C27B0; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        transactionPageButton.setOnAction(e -> {

            Main.prevScene = primaryStage.getScene();
            primaryStage.setScene(new Scene(new CreateTransactionsView(primaryStage)));
            primaryStage.show();
        });
        setMargin(transactionPageButton, new Insets(5));

        Button btnNotification = new Button("View Notifications");
        btnNotification.setStyle("-fx-background-color: #63C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
        btnNotification.setOnAction(e -> {

        	Main.prevScene = primaryStage.getScene();
        	primaryStage.setScene(new Scene(new InboxView(primaryStage)));
        	primaryStage.show();
        	
        });
        setMargin(btnNotification, new Insets(5));

        getChildren().addAll(lineChart, backButton, welcomeLabel, projectButtonsBox, transactionPageButton,
                viewTransactionsButton, btnNotification);
    }
}
