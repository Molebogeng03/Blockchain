package block.chain.views;


public class TransactionData {
	
    private String month;
    private double amount;

    public TransactionData(String month, double amount) {
        this.month = month;
        this.amount = amount;
    }

    public String getMonth() {
        return month;
    }

    public double getAmount() {
        return amount;
    }
      
 
}

