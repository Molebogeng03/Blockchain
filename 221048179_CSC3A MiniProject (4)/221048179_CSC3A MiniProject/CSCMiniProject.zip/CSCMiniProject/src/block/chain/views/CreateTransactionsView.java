package block.chain.views;

import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.layout.HBox;

//import java.time.LocalDateTime;

//import block.chain.controllers.MySqlDBController;
import block.chain.controllers.CreateTransactionController;
import block.chain.models.ProjectPriceMapper;

public class CreateTransactionsView extends VBox{

	private Stage primaryStage;
	
	public CreateTransactionsView(Stage primaryStage) {
		
		this.primaryStage = primaryStage;
		primaryStage.setResizable(false);
		
		initComponents();
	}
	
	private void initComponents() {
		
		setPrefWidth(700);
		setPrefHeight(400);
		
		Button backButton = new Button("Back to dashboard");
		backButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		setMargin(backButton,new Insets(7,0,20,10));
		backButton.setOnAction(e->{
			
			// Before going back to the dashboard update the graph.
			 if(CreateTransactionController.ISCHANGED) {	        	
	        	DashboardView.lineChart = CreateTransactionController.updateGraph(Main.transData);
	        	Main.dashboardView.getChildren().set(0, DashboardView.lineChart);
	        	CreateTransactionController.ISCHANGED = false;	        		     	        	
			 }
			 
			primaryStage.setScene(Main.prevScene);						
		});
		
		Label lblHeading = new Label("Make transaction");
		//lblHeading.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		lblHeading.setFont(Font.font(30));
		setMargin(lblHeading, new Insets(10,0,20,260));
		
		Label lblSender = new Label("Sender:");
		lblSender.setFont(Font.font(20));
		setMargin(lblSender, new Insets(5,0,0,5));
		
		TextField tfSender = new TextField();
		tfSender.setFont(Font.font(16));
		tfSender.setPrefColumnCount(30);
		setMargin(tfSender, new Insets(5,0,0,5));
		
		HBox senderBox = new HBox(30);
		senderBox.getChildren().addAll(lblSender,tfSender);
		setMargin(senderBox, new Insets(5,0,20,47));
		
		Label lblReceiver = new Label("Receiver:");
		lblReceiver.setFont(Font.font(19));
		setMargin(lblReceiver, new Insets(5,0,0,5));
		
		TextField tfReceiver = new TextField();
		tfReceiver.setFont(Font.font(16));
		tfReceiver.setPrefColumnCount(30);
		setMargin(tfReceiver, new Insets(5,0,0,5));	
		
		HBox receiverBox = new HBox(40);
		receiverBox.getChildren().addAll(lblReceiver, tfReceiver);
		setMargin(receiverBox, new Insets(5,0,10,30));
		
		Label lblAmount = new Label("Amount: R");
		lblAmount.setFont(Font.font(19));
		setMargin(lblAmount, new Insets(5,0,0,5));
		
		TextField tfAmount = new TextField();
		tfAmount.setFont(Font.font(16));
		tfAmount.setPrefColumnCount(30);
		setMargin(tfAmount, new Insets(5,0,0,5));	
		
		HBox amountBox = new HBox(40);
		amountBox.getChildren().addAll(lblAmount, tfAmount);
		setMargin(amountBox, new Insets(5,0,10,18));
		
		Label lblProjectID = new Label("Project ID:");
		lblProjectID.setFont(Font.font(19));
		setMargin(lblProjectID, new Insets(5,0,0,5));
		
		TextField tfProjectID = new TextField();
		tfProjectID.setFont(Font.font(16));
		tfProjectID.setPrefColumnCount(30);
		setMargin(tfProjectID, new Insets(5,0,0,5));
		
		HBox projectDetailsBox = new HBox(40);
		projectDetailsBox.getChildren().addAll(lblProjectID, tfProjectID);
		setMargin(projectDetailsBox, new Insets(5,0,10,20));		
					
		Button sendButton = new Button("Transact");
		sendButton.setFont(Font.font(18));
		setMargin(sendButton, new Insets(10,0,20,300));
		sendButton.setOnAction(e->{
									
			if(!tfSender.getText().equals("") && !tfReceiver.getText().equals("") && !tfAmount.getText().equals("") &&
					!tfProjectID.getText().equals("")) {
				
				double amount = Double.parseDouble(tfAmount.getText());
				ProjectPriceMapper ppMapper = new ProjectPriceMapper(tfProjectID.getText(), amount);
				boolean good = CreateTransactionController.createTransaction(tfSender.getText(), tfReceiver.getText(), ppMapper);
				
				if(good)
					showConfirmationAlert("success","Transaction made successfully.");
				else
					showConfirmationAlert("error","Failed to make the transaction. Make sure the receiver/contractor and the project"
							+ " ID" + " also exists.");
			}
			else {
				showConfirmationAlert("error","Failed to make the transaction.");
			}
									
		});
		
		getChildren().addAll(backButton, lblHeading, senderBox, receiverBox, amountBox, projectDetailsBox, sendButton);

	}
	
	private void showConfirmationAlert(String type, String msg) {
        Alert alert;
        
        if(type.equals("success")) {
        
        	alert = new Alert(Alert.AlertType.INFORMATION);
        	alert.setTitle("Transaction Success");            
            alert.setContentText(msg);
        }
        else {
        	alert = new Alert(Alert.AlertType.ERROR);
        	alert.setTitle("Error");           
            alert.setContentText(msg);
        }
        
        alert.setHeaderText(null);
        alert.showAndWait();
    }
	
	
}
