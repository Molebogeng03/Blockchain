package block.chain.views;

import block.chain.models.Project;
import block.chain.models.UserType;
import block.chain.controllers.ProjectsController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ProjectsView extends VBox{

	private ObservableList<Project> projects;
	
	// visual components
	private Stage primaryStage;
	private ListView<Project> listView;
	
	public ProjectsView(Stage primaryStage) {
		this.primaryStage = primaryStage;
		projects = FXCollections.observableArrayList(ProjectsController.getProjectAllocated());
		
		initComponents();
	}
	
	protected void initComponents() {
		
		setPrefWidth(990);
		setPrefHeight(600);
		
		listView = createListView(projects);
		
		Button backButton = new Button("Back to dashboard");
		backButton.setStyle("-fx-background-color: #61C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		backButton.setOnAction(e->{
									
			if(Main.LOGGED_IN.getUserType().equals(UserType.GOVERNMENT_OFFICIAL))
				primaryStage.setScene(Main.dashboardScene);
			else
				primaryStage.setScene(Main.contractorDashboardScene);
			
			primaryStage.show();
		});
		setMargin(backButton,new Insets(5));
		
		Button btnCompleted = new Button("Completed Projects");
		btnCompleted.setStyle("-fx-background-color: #77C5DA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnCompleted.setOnAction(e->{
						
			listView = createListView(ProjectsController.getProjectsByStatus('C'));
			getChildren().set(1, listView);
		});
		setMargin(btnCompleted, new Insets(5));
		
		Button btnPending = new Button("Pending Projects");
		btnPending.setStyle("-fx-background-color: #63C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnPending.setOnAction(e->{
			
			listView = createListView(ProjectsController.getProjectsByStatus('P'));
			getChildren().set(1, listView);
		});
		setMargin(btnPending, new Insets(5));
		
		HBox btnBox = new HBox(10);
		setMargin(btnBox, new Insets(5,0,0,350));
		btnBox.getChildren().addAll(btnCompleted,btnPending);
		
		getChildren().addAll(backButton,listView, btnBox);
				
	}
	
	private ListView<Project> createListView(ObservableList<Project> projects){
					
		listView = new ListView<>(projects);
		listView.setPrefHeight(500);
		listView.setPrefWidth(990);
		listView.setOnMouseClicked(e->{
			Project project = listView.getSelectionModel().getSelectedItem();
			
			if(project != null) {
			
				Main.prevScene = primaryStage.getScene();
				ProjectDetailsView projectDetails = new ProjectDetailsView(project, primaryStage);			
				primaryStage.setScene(new Scene(projectDetails));
				primaryStage.show();
			}
			
		});
		setMargin(listView,new Insets(5));
		
		return listView;
	}
}
