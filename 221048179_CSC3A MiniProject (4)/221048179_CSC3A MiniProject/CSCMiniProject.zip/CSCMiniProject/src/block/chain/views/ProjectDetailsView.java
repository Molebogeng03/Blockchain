package block.chain.views;

import block.chain.controllers.InboxController;
import block.chain.controllers.ProjectsController;
import block.chain.controllers.UserController;
import block.chain.models.Inbox;
import block.chain.models.Message;
import block.chain.models.Project;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ProjectDetailsView extends VBox{

	private Project project;
	private Stage primaryStage;
	
	public ProjectDetailsView(Project project, Stage stage) {
		
		this.project = project;
		primaryStage = stage;
		initComponents();
	}
		
	protected void initComponents() {
		
		setPrefWidth(700);
		setPrefHeight(700);

		Label lblHeading = new Label("Project Details");
		lblHeading.setFont(Font.font(16));	
		setMargin(lblHeading,new Insets(5,0,0,250));
		
		Label lblProjectId = new Label("Project ID: ");
		setMargin(lblProjectId,new Insets(5));
		
		TextField tfProjectId = new TextField();
		tfProjectId.setPrefColumnCount(10);
		tfProjectId.setText(project.getID().toString());
		tfProjectId.setEditable(false);
		setMargin(tfProjectId,new Insets(5));
		
		Label lblName = new Label("Project Name: ");
		setMargin(lblName,new Insets(5));
		
		TextField tfName = new TextField();
		tfName.setPrefColumnCount(10);
		tfName.setText(project.getName());
		tfName.setEditable(false);
		setMargin(tfName,new Insets(5));
		
		Label lblDescription = new Label("Description: ");
		setMargin(lblDescription,new Insets(5));
		
		TextArea taDescription = new TextArea();
		taDescription.setText(project.getDescription());
		taDescription.setEditable(false);
		setMargin(taDescription,new Insets(5));
		
		Label lblStartDate = new Label("Start Date: ");
		setMargin(lblStartDate,new Insets(5));
		
		TextField tfStartDate = new TextField();
		tfStartDate.setPrefColumnCount(10);
		tfStartDate.setText(project.getStartDate().toString());
		tfStartDate.setEditable(false);
		setMargin(tfStartDate,new Insets(5));
		
		Label lblEndDate = new Label("End Date: ");
		setMargin(lblEndDate,new Insets(5));
		
		TextField tfEndDate = new TextField();
		tfEndDate.setPrefColumnCount(10);
		tfEndDate.setText(project.getEndDate().toString());
		tfEndDate.setEditable(false);
		setMargin(tfEndDate,new Insets(5));
		
		Label lblBudget = new Label("Budget: R");
		setMargin(lblBudget,new Insets(5));
		
		TextField tfBudget = new TextField();
		tfBudget.setPrefColumnCount(10);
		tfBudget.setText(Double.toString(project.getBudget()));
		tfBudget.setEditable(false);
		setMargin(tfBudget,new Insets(5));
		
		Label lblOfficialUsername = new Label("Official username: ");
		setMargin(lblOfficialUsername,new Insets(5));
		
		TextField tfOfficialUsername = new TextField();		
		tfOfficialUsername.setText(project.getOfficial().getUsername());
		tfOfficialUsername.setEditable(false);
		setMargin(tfOfficialUsername,new Insets(5));
			
		Label lblContractorUsername = new Label("Contractor username: ");
		setMargin(lblContractorUsername,new Insets(5));
		
		TextField tfContractorUsername = new TextField();
		tfContractorUsername.setPrefColumnCount(10);
		tfContractorUsername.setText(project.getContractor().getUsername());
		tfContractorUsername.setEditable(false);
		setMargin(tfContractorUsername,new Insets(5));		
		
		Label lblIsCompleted = new Label("Is Completed:(To update to completed,set to true.) ");
		setMargin(lblIsCompleted,new Insets(5));
		
		TextField tfIsCompleted = new TextField();
		tfIsCompleted.setPrefColumnCount(10);
		tfIsCompleted.setText(Boolean.toString(project.getIsCompleted()));
		tfIsCompleted.setEditable(true);
		setMargin(tfIsCompleted,new Insets(5));
				
		Button btnUpdate = new Button("Update Completed");	
		btnUpdate.setStyle("-fx-background-color: #63C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnUpdate.setOnAction(e->{
			
			if(!tfProjectId.getText().equals("") && !tfIsCompleted.getText().equals("")) {
				
				if(ProjectsController.updateProject(tfProjectId.getText(), Boolean.parseBoolean(tfIsCompleted.getText()))) {
					
					Inbox officialInbox = InboxController.getInbox(UserController.getUser(tfOfficialUsername.getText()));
					String msg = "Project Completed: {ID - " + tfProjectId.getText() + " , Name: " + tfName.getText() + "}";
					Message newMessage = new Message(tfContractorUsername.getText(), tfOfficialUsername.getText(), msg);
					
					if(officialInbox == null) {
						
						officialInbox = new Inbox(UserController.getUser(tfOfficialUsername.getText()));
						Main.INBOXES.add(officialInbox);
					}
					
					officialInbox.addMessage(newMessage);										
					
					showConfirmationAlert("success","Project status successfully updated!");
				}											
			}
			
		});

		setMargin(btnUpdate, new Insets(5));
	
		Button btnBack = new Button("Back");
		btnBack.setStyle("-fx-background-color: #63C5BA; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		btnBack.setPrefWidth(100);
		btnBack.setOnAction(e->{
			
			primaryStage.setScene(Main.prevScene);
			primaryStage.show();
		});
		setMargin(btnBack, new Insets(5));
		
		HBox btnBox = new HBox(10);
		btnBox.getChildren().addAll(btnBack, btnUpdate);
		setMargin(btnBox, new Insets(5,0,5,250));
		
		getChildren().addAll(lblHeading,
				lblProjectId, tfProjectId,
				lblName, tfName, 
				lblDescription, taDescription,
				lblStartDate, tfStartDate, 
				lblEndDate,tfEndDate,
				lblBudget, tfBudget,
				lblOfficialUsername, tfOfficialUsername,
				lblContractorUsername, tfContractorUsername, 
				lblIsCompleted, tfIsCompleted, btnBox);
	}

	private void showConfirmationAlert(String type, String msg) {
		
        Alert alert;
        
        if(type.equals("success")) {
        
        	alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText(msg);
        }
        else {
        	alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(msg);
        }
        
        
        alert.showAndWait();
    }
	
}
