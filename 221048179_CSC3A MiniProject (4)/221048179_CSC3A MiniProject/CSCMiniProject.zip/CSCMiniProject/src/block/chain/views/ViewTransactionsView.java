package block.chain.views;

import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.text.Font;

import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;
import block.chain.controllers.ViewTransationsController;
import block.chain.models.ProjectPriceMapper;

public class ViewTransactionsView<T> extends VBox{

	// This is a list of transactions to display.
	private ObservableList<Transaction<ProjectPriceMapper>> transactions;
	// The controller will be used to fetch the data from the blockchain.

	// Visual components
	private ListView<Transaction<ProjectPriceMapper>> listView;
	private Stage primaryStage;	
	
	public ViewTransactionsView(Blockchain<ProjectPriceMapper> blockchain, Stage primaryStage) {
					
		this.transactions = FXCollections.observableArrayList(ViewTransationsController.getTransactions());
		this.primaryStage = primaryStage;
		primaryStage.setResizable(false);
		
		initComponents();
	}	
	
	public void initComponents() {
		
		setPrefHeight(600);
		setPrefWidth(920);
		setFillWidth(true);
		
		Label heading = new Label("All Transactions");
		heading.setFont(new Font(20));
				
		listView =  new ListView<>(transactions);
		listView.setPrefHeight(500);
		listView.setPrefWidth(920);		
		
		Button backButton = new Button("Back to dashboard");
		backButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px;");
		backButton.setOnAction(e->{
			primaryStage.setScene(Main.prevScene);
		});
				
		getChildren().addAll(backButton,heading,listView);				
		setMargin(backButton, new Insets(5,0,10,3));
		setMargin(heading,new Insets(0,0,10,400));
		setMargin(listView,new Insets(0,10,0,10));
				
	}
	
}
