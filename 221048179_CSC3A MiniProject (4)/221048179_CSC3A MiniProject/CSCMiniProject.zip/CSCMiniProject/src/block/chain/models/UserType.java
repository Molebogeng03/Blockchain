package block.chain.models;

public enum UserType {
    GOVERNMENT_OFFICIAL,
    CONTRACTOR
}
