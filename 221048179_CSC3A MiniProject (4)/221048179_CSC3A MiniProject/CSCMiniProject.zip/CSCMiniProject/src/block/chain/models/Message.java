package block.chain.models;

public class Message {

	private String senderUsername;
	private String receiverUsername;
	private String message;	
	
	public Message(String sUsername, String rUsername, String msg) {
				
		senderUsername = sUsername;
		receiverUsername = rUsername;
		message = msg;
	}

	public String getSenderUsername() {
		return senderUsername;
	}

	public void setSenderUsername(String officialUsername) {
		this.senderUsername = officialUsername;
	}

	public String getReceiverUsername() {
		return receiverUsername;
	}

	public void setReceiverUsername(String contractorUsername) {
		this.receiverUsername = contractorUsername;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
