package block.chain.models;

public class ProjectPriceMapper {

	private String projectID;
	private double amount;

	public ProjectPriceMapper(String projID, double amount) {
		projectID = projID;
		this.amount = amount;
	}
	
	public void setProjectID(String id) {
		projectID = id;
	}
	
	public String getProjectID() {
		return projectID;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public double getAmount() {
		return amount;
	}
	
	@Override
	public String toString() {
		return "{Project_ID: " + getProjectID() + ",Amount_Paid: R" + getAmount() + "}";
	}
}
