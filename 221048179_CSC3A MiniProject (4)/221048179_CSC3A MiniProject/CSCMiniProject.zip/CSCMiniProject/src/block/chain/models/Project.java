package block.chain.models;

import java.time.LocalDateTime;
import java.util.UUID;

public class Project {

	private UUID ID;
	private String name;
	private String description;
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	private User official;
	private User contractor;	
	private double budget;
	private boolean isCompleted;

	public Project(String name, String description, LocalDateTime startDate, LocalDateTime endDate, double budget, User official,
			User contractor, boolean isCompleted) {
		
		ID = UUID.randomUUID();
		this.name = name;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.budget = budget;
		this.official = official;
		this.contractor = contractor;
		this.isCompleted = isCompleted;
	}
	
	public boolean getIsCompleted() {
		return isCompleted;
	}
	
	public void setIsCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}
	
	public double getBudget() {
		return budget;
	}
	
	public void setBudget(double amount) {
		budget = amount;
	}
	
	public User getOfficial() {
		return official;
	}

	public void setOfficial(User official) {
		this.official = official;
	}

	public User getContractor() {
		return contractor;
	}

	public void setContractor(User contractor) {
		this.contractor = contractor;
	}
	
	public UUID getID() {
		return ID;
	}

	public void setID(UUID iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		
		return "Project{ID: " + getID() + ",Name: " + getName() + ",Start: " + getStartDate() + ",End: " + getEndDate() + ",Budget: R" + 
				getBudget() + ",Official: " + getOfficial().getUsername() + ",Contractor: " + getContractor().getUsername() + 
				",Completed:" + getIsCompleted() + "}";		
	}
}
