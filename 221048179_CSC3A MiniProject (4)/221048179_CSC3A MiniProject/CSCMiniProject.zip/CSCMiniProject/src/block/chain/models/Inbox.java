package block.chain.models;

import java.util.ArrayList;

public class Inbox {

	private User owner;
	private ArrayList<Message> messages;
	private int numMessages;
	
	public Inbox(User owner) {
		
		this.owner = owner;
		messages = new ArrayList<>();
		++numMessages;
	}
	
	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	
	public void setNumMessages(int numMessages) {
		this.numMessages = numMessages;
	}
	
	public int getNumMessages() {
		return numMessages;
	}
	
	public void addMessage(Message newMessage) {
		messages.add(newMessage);
		++numMessages;
	}
	
	public ArrayList<Message> getMessages(){
		return messages;
	}
}
