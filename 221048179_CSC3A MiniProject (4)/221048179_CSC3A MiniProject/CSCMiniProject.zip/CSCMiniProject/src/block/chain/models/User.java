package block.chain.models;

import java.io.Serializable;

public class User implements Serializable{
		    
	private static final long serialVersionUID = 1L;
	private String username;
    private String password;
    private UserType userType;
    private boolean isActive;

    public User(String username, String password, UserType userType) {
        this.username = username;
        this.password = password;
        this.userType = userType;
        isActive = true;
    }

    public User(String username, String password, UserType userType, boolean status) {
        this.username = username;
        this.password = password;
        this.userType = userType;
        isActive = status;
    }
    
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public UserType getUserType() {
        return userType;
    }
    
    public boolean getStatus() {
    	return isActive;
	}
    
    public void setStatus(boolean isActive) {
    	this.isActive = isActive;
    }
}
