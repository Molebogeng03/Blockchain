package block.chain.controllers;

import block.chain.models.ProjectPriceMapper;
import block.chain.models.User;
import block.chain.views.Main;
import acsse.csc03a3.Transaction;

import java.util.ArrayList;
import java.util.List;

public class ViewTransationsController<T> {
	
	public static List<Transaction<ProjectPriceMapper>> getTransactions(){
					
		ArrayList<Transaction<ProjectPriceMapper>> transactions = new ArrayList<>();
		
		for(Transaction<ProjectPriceMapper> trans : Main.TRANSACTIONS) {
			
			User loggedInUser = Main.LOGGED_IN;
			boolean isSenderOrReceiver = loggedInUser.getUsername().equals(trans.getSender()) || loggedInUser.getUsername().equals(trans.getReceiver());
			
			if(trans != null && isSenderOrReceiver)
				transactions.add(trans);							
		}			
		
		return transactions;
	}	
}
