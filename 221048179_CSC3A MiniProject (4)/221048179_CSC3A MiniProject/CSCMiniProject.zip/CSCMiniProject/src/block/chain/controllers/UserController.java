package block.chain.controllers;

import block.chain.models.User;
import block.chain.models.UserType;
import block.chain.views.Main;

public class UserController {

	public static boolean login(User user) {
	
		for(User u : Main.USERS) {		
			
		  if(u != null && u.getPassword().equals(user.getPassword()) && u.getUsername().equals(user.getUsername()) && 
				  u.getStatus() == user.getStatus() && u.getUserType().equals(user.getUserType())) {
		 
			  Main.LOGGED_IN = u;			  
			return true;							
		  }
		}		
				
		return false;
	}
	
	public static boolean updateAccount(User user) {
			
		for(User u : Main.USERS) {
			
			if(u != null && u.getUsername().equals(user.getUsername()) && u.getPassword().equals(user.getPassword())) {
				
				u.setStatus(user.getStatus());
				return true;
			}
		}
		
		return false;
	}	
		
	public static boolean createAccount(User user) {
		
		return Main.USERS.add(user);
	}
	
	public static boolean officialExists(String username) {
		
		for(User user : Main.USERS) {
			
			if(user.getUsername().equals(username) && user.getUserType().equals(UserType.GOVERNMENT_OFFICIAL))
				return true;			
		}
		
		return false;
	}
	
	public static boolean contractorExists(String username) {
		
		for(User user : Main.USERS) {
			
			if(user.getUsername().equals(username) && user.getUserType().equals(UserType.CONTRACTOR))
				return true;			
		}
		
		return false;
	}
	
	public static User getUser(String username, String password) {
		
		for(User user: Main.USERS) {
			if(user.getUsername().equals(username) && user.getPassword().equals(password))
				return user;
		}
		
		return null;
	}
	
	public static User getUser(String username) {
		
		for(User user: Main.USERS) {
			if(user.getUsername().equals(username))
				return user;
		}
		
		return null;
	}
}
