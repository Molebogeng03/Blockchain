package block.chain.controllers;

import java.util.List;

import acsse.csc03a3.Transaction;
import block.chain.models.Inbox;
import block.chain.models.Message;
import block.chain.models.ProjectPriceMapper;
import block.chain.models.User;
import block.chain.views.Main;
import block.chain.views.TransactionData;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class CreateTransactionController {
	
	// This flag will observe any changes to the Transactions list
	// to notify the graph that it must be updated.
	public static boolean ISCHANGED = false;
	
	public static boolean createTransaction(String sender, String receiver, ProjectPriceMapper data) {
		
		// check if the official, the contractor and the project exists.
		if(!UserController.officialExists(sender) || !UserController.contractorExists(receiver) ||
				!ProjectsController.projectExists(data.getProjectID()))
			return false;						
		
		Transaction<ProjectPriceMapper> newTransaction = new Transaction<>(sender, receiver,data);
		boolean isAdded = Main.TRANSACTIONS.add(newTransaction);		
		Main.BLOCKCHAIN.addBlock(Main.TRANSACTIONS);
		ISCHANGED = true;
		Main.lineChart = updateGraph(getGraphData());
		
		// Create a inbox.
		User contractor = UserController.getUser(receiver);
		
		if(contractor != null) {
			
			Inbox inbox = null;
			String msg =  "R" + data.getAmount() + " loaded into your account.";
			Message newMessage = new Message(sender, receiver,msg);						
			
			if(InboxController.getInbox(contractor) != null) {
			
				inbox = InboxController.getInbox(contractor);
				inbox.addMessage(newMessage);
			}
			else {
				
				inbox = new Inbox(contractor);
				inbox.addMessage(newMessage);
				Main.INBOXES.add(inbox);
			}
																
		}
		
		return isAdded; 
	}
	
	public static LineChart<String, Number> updateGraph(List<TransactionData> transactionData) {
		
		return createLineChart(transactionData);
	}
	
	private static LineChart<String, Number> createLineChart(List<TransactionData> transactionData) {
        // Create a line chart to visualize transactions
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Transactions Overview");
        lineChart.setPrefSize(600, 300);

        // Create a series for the chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Transactions");

        // Add data to the series from the transaction data list
        for (TransactionData data : transactionData) {
            series.getData().add(new XYChart.Data<>(data.getMonth(), data.getAmount()));
        }

        // Add the series to the chart
        lineChart.getData().add(series);

        return lineChart;
    }
	
	public static List<TransactionData> getGraphData(){		

		for(Transaction<ProjectPriceMapper> trans : Main.TRANSACTIONS) {						
			TransactionData tData = new TransactionData("May",trans.getData().getAmount());
			Main.transData.add(tData);
		}
		
		return Main.transData;
	}
	
}
