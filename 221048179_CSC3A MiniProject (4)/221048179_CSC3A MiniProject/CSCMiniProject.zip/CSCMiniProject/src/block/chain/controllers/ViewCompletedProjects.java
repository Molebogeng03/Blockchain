package block.chain.controllers;

import block.chain.models.ProjectPriceMapper;
//import block.chain.models.Transaction;
//import block.chain.models.Blockchain;
//import block.chain.models.Block;
import block.chain.views.Main;
import acsse.csc03a3.Transaction;

import java.util.ArrayList;
import java.util.List;

public class ViewCompletedProjects<T> {

	private static ArrayList<Transaction<ProjectPriceMapper>> transactions;	
	
	public ViewCompletedProjects() {		
		transactions = new ArrayList<>();
	}
	
	public List<Transaction<ProjectPriceMapper>> getTransactions(){
								
		for(Transaction<ProjectPriceMapper> trans : Main.TRANSACTIONS) {
			
			if(trans != null)
				transactions.add(trans);
		}			
		
		return transactions;
	}	
}
