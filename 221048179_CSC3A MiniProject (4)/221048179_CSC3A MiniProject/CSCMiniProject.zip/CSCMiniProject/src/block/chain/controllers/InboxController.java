package block.chain.controllers;

import java.util.ArrayList;

import block.chain.models.Inbox;
import block.chain.models.User;
import block.chain.views.Main;

public class InboxController {

	public static ArrayList<Inbox> getInboxes(String username, String password){
		
		ArrayList<Inbox> inboxes = new ArrayList<>();

		if(UserController.getUser(username, password) != null) {
		
			for(Inbox inbox : Main.INBOXES) {
				
				if(inbox != null && inbox.getOwner().getUsername().equals(username) && inbox.getOwner().getPassword().endsWith(password)) 
					inboxes.add(inbox);
			}					
		}	
		
		return inboxes;
	}
	
	public static Inbox getInbox(User user) {
		
		for(Inbox inbox : Main.INBOXES) {
			
			if(inbox != null && inbox.getOwner().getUsername().equals(user.getUsername()) && inbox.getOwner().getPassword().equals(user.getPassword()))
				return inbox;
		}
		
		// necessary
		return null;
	}
	
}
