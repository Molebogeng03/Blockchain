package block.chain.controllers;

import java.time.LocalDateTime;
import java.util.ArrayList;

import block.chain.models.User;
import block.chain.models.UserType;
import block.chain.models.Project;
import block.chain.views.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ProjectsController {

	public static boolean createProject(String name, String description, String startDate, String endDate, double budget, String official,
			String contractor, boolean isCompleted) {
		
		// Get the official and contractor details.
		User offi = null;
		User contra = null;
		boolean foundUsers = false;
		
		for(User user : Main.USERS) {
			
			if(user.getUsername().equals(official))
				offi = new User(user.getUsername(), user.getPassword(),UserType.GOVERNMENT_OFFICIAL, true);								
			else if(user.getUsername().equals(contractor))
				contra = new User(user.getUsername(), user.getPassword(), UserType.CONTRACTOR, true);
			
			if(offi != null && contra != null) {
				foundUsers = true;
				break;
			}
		}			
		
		// Convert String dates to LocalDateTime.
		LocalDateTime sDate = LocalDateTime.parse(startDate);
		LocalDateTime eDate = LocalDateTime.parse(endDate);
		
		if(foundUsers) {
			
			Project newProject = new Project(name, description, sDate, eDate, budget, offi, contra, isCompleted);
			Main.PROJECTS.add(newProject);
			return true;
		}
		
		return false;
	}
	
	public static ObservableList<Project> getProjectsByStatus(char action){
		
		ArrayList<Project> projects = new ArrayList<>();
		
		for(Project proj : Main.PROJECTS) {
			
			if(action == 'C' && proj.getIsCompleted())
				projects.add(proj);
			else if(action == 'P' && !proj.getIsCompleted())
				projects.add(proj);
		}
		
		return FXCollections.observableArrayList(projects);
	}
	
	public static  boolean updateProject(String id, boolean isCompleted) {
		
		for(Project project : Main.PROJECTS) {
			
			if(project.getID().toString().equals(id)) {
				
				project.setIsCompleted(isCompleted);
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean projectExists(String id) {
		
		for(Project project : Main.PROJECTS) {
			
			if(project.getID().toString().equals(id))
				return true;
		}
		
		return false;
	}
	
	public static ArrayList<Project> getProjectAllocated(){
		
		ArrayList<Project> allocatedProjects = new ArrayList<>();
		
		for(Project proj : Main.PROJECTS) {
			
			boolean isAllocated = proj.getContractor().getUsername().equals(Main.LOGGED_IN.getUsername()) &&
								  proj.getContractor().getPassword().equals(Main.LOGGED_IN.getPassword());
			
			if(proj != null && isAllocated)
				allocatedProjects.add(proj);			
		}
		
		return allocatedProjects;
	}
}
